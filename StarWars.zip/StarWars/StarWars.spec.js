/// <reference types="Cypress" />

//describe('Avaliacao Tecnica', () => {
  it('People', function(){
    cy.visit('https://swapi.co/api/people/1/')
    cy.get('.meta > :nth-child(1)')
  })

  it('Procurando por Luke Skywalker', () => {
    
    const person = {
      name: "Luke Skywalker",
      height: 172,
      mass: 77,
      hair_color: "blond",
      skin_color: "fair",
      eye_color: "blue",
      birth_year: "19BBY",
      gender: "male"  
    }
    assert.isObject(person, 'value is object')
  })


  it('Planet', function(){
    cy.visit('https://swapi.co/api/planets/1/')
    cy.get('.meta > :nth-child(1)')
  })

  it('Procurando pelo Planeta Tatooine', () => {
    
    const person = {
      name: "Tatooine",
      rotation_period: "23",
      orbital_period: "304",
      diameter: "10465",
      climate: "arid",
      gravity: "1 standard",
      terrain: "desert",
      surface_water: "1",
      population: "200000"
    }
    assert.isObject(person, 'value is object')
  })
